<?php include('header.php'); ?>
				<section>
					<div class="rev_slider_wrapper">			
					<!-- START REVOLUTION SLIDER 5.0 auto mode -->
					<div id="slider-h1" class="rev_slider slider-home-1" data-version="5.0">
						<ul>	
							<!-- SLIDE  -->
							<li data-transition="parallaxtoright" data-masterspeed="1000" >
								
								<!-- MAIN IMAGE -->
								<img src="images/Slider/1.jpg"  alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10">							

								<!-- LAYER NR. 1 -->
								<div class="tp-caption heading-2 white-text" 							
									 data-x="center" 
									 data-y="center"  data-voffset="-80" 									 
							  		 data-transform_in="y:-80px;opacity:0;s:800;e:easeInOutCubic;" 
			 						 data-transform_out="y:-80px;opacity:0;s:300;" 
								
									 data-start="1000" 				 							
									>bedroom interior
								</div>
								<!-- LAYER NR. 2 -->
								<div class="tp-caption heading-1 white-text text-cap " 						
									 data-x="center" 
									 data-y="center" 					
									 data-transform_in="y:80px;opacity:0;s:800;e:easeInOutCubic;" 
				 					 data-transform_out="y:80px;opacity:0;s:300;" 
									 data-start="1400" 
									>Design Awards
								</div>
								
								<!-- LAYER NR. 3 -->
								<div class="tp-caption btn-1" 							
									 data-x="center"  data-hoffset="-85"
									 data-y="center"  data-voffset="100" 
								  	 data-transform_in="y:100px;opacity:0;s:800;e:easeInOutCubic;" 
				 					data-transform_out="y:200px;opacity:0;s:300;" 
									 data-start="1600" 
									>	
									<a href="portfolioGrid_1.html" class="ot-btn btn-main-color text-cap ">Our Projects</a>  
	              					
								</div>
								<!-- LAYER NR. 4 -->
								<div class="tp-caption btn-2" 							
									 data-x="center"  data-hoffset="85"
									 data-y="center"  data-voffset="100" 
									 data-transform_in="y:100px;opacity:0;s:800;e:easeInOutCubic;" 
				 					 data-transform_out="y:200px;opacity:0;s:300;" 

									 data-start="1600" 
									>	
	              					<a href="contact.html" class="ot-btn btn-sub-color text-cap  ">Get a Quote</a> 
								</div>
								
							</li>
							<li data-transition="parallaxtoright" data-masterspeed="1000" >
								
								<!-- MAIN IMAGE -->
								<img src="images/Slider/2.jpg"  alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10">							

								<!-- LAYER NR. 1 -->
								<div class="tp-caption heading-2 white-text" 							
									 data-x="center" 
									 data-y="center"  data-voffset="-80" 									 
							  		 data-transform_in="y:-80px;opacity:0;s:800;e:easeInOutCubic;" 
			 						 data-transform_out="y:-80px;opacity:0;s:300;" 
								
									 data-start="1000" 				 							
									>bedroom interior
								</div>
								<!-- LAYER NR. 2 -->
								<div class="tp-caption heading-1 white-text text-cap " 						
									 data-x="center" 
									 data-y="center" 					
									 data-transform_in="y:80px;opacity:0;s:800;e:easeInOutCubic;" 
				 					 data-transform_out="y:80px;opacity:0;s:300;" 
									 data-start="1400" 
									>Design Awards
								</div>
								
								<!-- LAYER NR. 3 -->
								<div class="tp-caption btn-1" 							
									 data-x="center"  data-hoffset="-85"
									 data-y="center"  data-voffset="100" 
								  	 data-transform_in="y:100px;opacity:0;s:800;e:easeInOutCubic;" 
				 					data-transform_out="y:200px;opacity:0;s:300;" 
									 data-start="1600" 
									>	
									<a href="portfolioGrid_1.html" class="ot-btn btn-main-color text-cap ">Our Projects</a>  
	              					
								</div>
								<!-- LAYER NR. 4 -->
								<div class="tp-caption btn-2" 							
									 data-x="center"  data-hoffset="85"
									 data-y="center"  data-voffset="100" 
									 data-transform_in="y:100px;opacity:0;s:800;e:easeInOutCubic;" 
				 					 data-transform_out="y:200px;opacity:0;s:300;" 

									 data-start="1600" 
									>	
	              					<a href="contact.html" class="ot-btn btn-sub-color text-cap  ">Get a Quote</a> 
								</div>
								
							</li>
							<!-- SLIDE  -->
							<li data-transition="parallaxtoright" data-masterspeed="1000" >
								
								<!-- MAIN IMAGE -->
								<img src="images/Slider/3.jpg"  alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10">							

								<!-- LAYER NR. 1 -->
								<div class="tp-caption heading-2 white-text" 							
									 data-x="center" 
									 data-y="center"  data-voffset="-80" 									 
							  		 data-transform_in="y:-80px;opacity:0;s:800;e:easeInOutCubic;" 
			 						 data-transform_out="y:-80px;opacity:0;s:300;" 
								
									 data-start="1000" 				 							
									>bedroom interior
								</div>
								<!-- LAYER NR. 2 -->
								<div class="tp-caption heading-1 white-text text-cap " 						
									 data-x="center" 
									 data-y="center" 					
									 data-transform_in="y:80px;opacity:0;s:800;e:easeInOutCubic;" 
				 					 data-transform_out="y:80px;opacity:0;s:300;" 
									 data-start="1400" 
									>Design Awards
								</div>
								
								<!-- LAYER NR. 3 -->
								<div class="tp-caption btn-1" 							
									 data-x="center"  data-hoffset="-85"
									 data-y="center"  data-voffset="100" 
								  	 data-transform_in="y:100px;opacity:0;s:800;e:easeInOutCubic;" 
				 					data-transform_out="y:200px;opacity:0;s:300;" 
									 data-start="1600" 
									>	
									<a href="portfolioGrid_1.html" class="ot-btn btn-main-color text-cap ">Our Projects</a>  
	              					
								</div>
								<!-- LAYER NR. 4 -->
								<div class="tp-caption btn-2" 							
									 data-x="center"  data-hoffset="85"
									 data-y="center"  data-voffset="100" 
									 data-transform_in="y:100px;opacity:0;s:800;e:easeInOutCubic;" 
				 					 data-transform_out="y:200px;opacity:0;s:300;" 

									 data-start="1600" 
									>	
	              					<a href="contact.html" class="ot-btn btn-sub-color text-cap  ">Get a Quote</a>  
								</div>
								
							</li>
				
						</ul>			
					</div><!-- END REVOLUTION SLIDER -->
					</div><!-- END REVOLUTION SLIDER WRAPPER -->	
				</section>
				<!-- End Section Slider -->
		
				<section class="padding">
					<div class="container">
					<div class="row">
						<div class="title-block">
							<h2 class="title text-cap" >What we do</h2>
							<div class="divider divider-1">
								<svg class="svg-triangle-icon-container">
								  <polygon class="svg-triangle-icon" points="6 11,12 0,0 0"></polygon>
								</svg>
							</div>
						</div>
						<!-- End Title -->
						<div class="row">
							<div class="col-md-6">
								<div class="block-img-right">
									
									<div class="img-block"><img src="images/Services/1.jpg" class="img-responsive" alt="Image"></div>
									<div class="text-box">
										<h4 class="text-cap"><mark>Residential</mark> design</h4>
										<p>
											Quisque pulvinar libero dolor, quis bibendum eros euismod sit amet. Proin dapibus id diam at
										</p>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="block-img-left">
									<div class="img-block"><img src="images/Services/2.jpg" class="img-responsive" alt="Image"></div>
									<div class="text-box">
										<h4 class="text-cap"><mark>Ecommercial</mark> design</h4>
										<p>
											Quisque pulvinar libero dolor, quis bibendum eros euismod sit amet. Proin dapibus id diam at
										</p>
									</div>
									
								</div>
							</div>
							<div class="col-md-6">
								<div class="block-img-right mgb0">
									<div class="img-block"><img src="images/Services/3.jpg" class="img-responsive" alt="Image"></div>
									<div class="text-box">
										<h4 class="text-cap"><mark>Office</mark> design</h4>
										<p>
											Quisque pulvinar libero dolor, quis bibendum eros euismod sit amet. Proin dapibus id diam at
										</p>
									</div>
									
								</div>
							</div>
							<div class="col-md-6">
								<div class="block-img-left mgb0">
									<div class="img-block"><img src="images/Services/4.jpg" class="img-responsive" alt="Image"></div>
									<div class="text-box">
										<h4 class="text-cap"><mark>Hospital</mark> design</h4>
										<p>
											Quisque pulvinar libero dolor, quis bibendum eros euismod sit amet. Proin dapibus id diam at
										</p>
									</div>
									
								</div>
							</div>
						</div>
					</div>
					</div>
				</section>
				<!-- End Section What we do -->

				<section>
					<div class="promotion-box">
						<figure class="effect-layla">
							<img src="images/Promotion/1.jpg" alt="img06"/>
							<figcaption>
								<h3 class="text-cap white-text">Green Design</h3>
								<p>Inspired by nature and created comfortable space for your life</p>
								<a href="#" class="ot-btn btn-main-color text-cap">View Service</a>
							</figcaption>			
						</figure>
						<figure class="effect-layla">
							<img src="images/Promotion/2.jpg" alt="img06"/>
							<figcaption>
								<h3 class="text-cap white-text">we love space</h3>
								<p>Inspired by nature and created comfortable space for your life</p>
								<a href="portfolioGrid_1.html" class="ot-btn btn-main-color text-cap">Our Project</a>
							</figcaption>			
						</figure>
						<figure class="effect-layla">
							<img src="images/Promotion/3.jpg" alt="img06"/>
							<figcaption>
								<h3 class="text-cap white-text">Expert interior</h3>
								<p>Inspired by nature and created comfortable space for your life</p>
								<a href="shop_cart.html" class="ot-btn btn-main-color text-cap">View Shop</a>
							</figcaption>			
						</figure>
					</div>
				</section>
				<!-- End Section Promotion -->

				<section class="padding clearfix fixbug-inline-block ">
					<div class="container">
					<div class="row">
						<div class="title-block">
							<div class="title-block">
								<h2 class="title text-cap">Why Choose Us ?</h2>
								<div class="divider divider-1">
									<svg class="svg-triangle-icon-container">
									  <polygon class="svg-triangle-icon" points="6 11,12 0,0 0"></polygon>
									</svg>
								</div>
							</div>
						</div>
						<!-- End Title -->
						<div class="chooseus-container text-center">
								<div class="chooseus-item">
									<h4 class="text-cap">Creative</h4>
					              	<div class="chooseus-canvas-item">
						                   <svg class="svg-hexagon">
											  	<polygon class="hexagon" points="285 100,285 250,155 325,25 250,25 100,155 25"></polygon>
											</svg>
						                    <!-- End Hexagon -->
						                    <svg class="svg-triangle-dotted"  >
											  <polygon class="triangle-div" points="2 220,254 220,128 0"></polygon>
											</svg>
											<!-- End Triangle Dotted -->
											<div class="triangle-img-warp tri">
												<img src="images/Whychooseus/1.jpg" class="img-responsive" alt="Image">
											</div>
					            	</div>
					            </div>	

					            <!-- End -->				

					            <div class="chooseus-item">
									<a href="#"><h4 class="text-cap">Know - How</h4></a>
					              	<div class="chooseus-canvas-item">
						                   <svg class="svg-hexagon">
											  	<polygon class="hexagon" points="285 100,285 250,155 325,25 250,25 100,155 25"></polygon>
											</svg>
						                    <!-- End Hexagon -->
						                    <svg class="svg-triangle-dotted svg-tri-2"  >
											  <polygon class="triangle-div" points="2 220,254 220,128 0"></polygon>
											</svg>
											<!-- End Triangle Dotted -->
											<div class="triangle-img-warp tri2">
												<img src="images/Whychooseus/2.jpg" class="img-responsive" alt="Image">
											</div>
					            	</div>
					            </div>

					            <!-- End -->

				             	<div class="chooseus-item mgb0">
									<a href="#"><h4 class="text-cap">Devoted</h4></a>
					              	<div class="chooseus-canvas-item">
						                   <svg class="svg-hexagon">
											  	<polygon class="hexagon" points="285 100,285 250,155 325,25 250,25 100,155 25"></polygon>
											</svg>
						                    <!-- End Hexagon -->
						                    <svg class="svg-triangle-dotted svg-tri-3"  >
											  <polygon class="triangle-div" points="2 220,254 220,128 0"></polygon>
											</svg>
											<!-- End Triangle Dotted -->
											<div class="triangle-img-warp tri3">
												<img src="images/Whychooseus/3.jpg" class="img-responsive" alt="Image">
											</div>
					            	</div>
					            </div>

					             <!-- End -->

				             	<div class="chooseus-item mgb0">
									<a href="#"><h4 class="text-cap">Caring</h4></a>
					              	<div class="chooseus-canvas-item">
						                   <svg class="svg-hexagon">
											  	<polygon class="hexagon" points="285 100,285 250,155 325,25 250,25 100,155 25"></polygon>
											</svg>
						                    <!-- End Hexagon -->
						                    <svg class="svg-triangle-dotted svg-tri-4"  >
											  <polygon class="triangle-div" points="2 220,254 220,128 0"></polygon>
											</svg>
											<!-- End Triangle Dotted -->
											<div class="triangle-img-warp tri4">
												<img src="images/Whychooseus/4.jpg" class="img-responsive" alt="Image">
											</div>
					            	</div>
					            </div>
						</div>						
					</div>
					</div>
				</section>
				<!-- End Section Why Choose Us -->

				<section class="padding bg-grey padding-bottom-0">
					<div class="title-block">
						<h2 class="title text-cap">Lastest Projects</h2>
						<div class="divider divider-1">
							<svg class="svg-triangle-icon-container">
							  <polygon class="svg-triangle-icon" points="6 11,12 0,0 0"></polygon>
							</svg>
						</div>
					</div>
						<!-- End Title -->
	                      <div class="lastest-project-warp clearfix">
	                          	<div class="projectFilter project-terms line-effect-2">
		                                <a href="#" data-filter="*" class="current text-cap"><h4>All Projects</h4></a>
		                                <a href="#" data-filter=".Residential" class="text-cap"><h4>Residential</h4></a>
		                                <a href="#" data-filter=".Ecommercial" class="text-cap"><h4>Ecommercial</h4></a>
		                                <a href="#" data-filter=".Office" class="text-cap"><h4>Office</h4></a>
		                                <a href="#" data-filter=".Hospital" class="text-cap"><h4>Hospital</h4></a>
	                          	</div> <!-- End Project Fillter -->

	                            <div class="clearfix projectContainer">
	             
	                              <div class="element-item  Residential">
		                                
		                                  <img src="images/Project/1.jpg" class="img-responsive" alt="Image">
		                                <div class="project-info">
		                                  	<a href="portfolioDetail.html"><h4 class="title-project text-cap text-cap">Dream House</h4></a>
		                                    <a href="portfolioDetail.html" class="cateProject">Residential</a>
		                                </div>
	                              </div>
	                           
	                              <div class="element-item Residential ">
		                                
	                                   	<img src="images/Project/2.jpg" class="img-responsive" alt="Image">
		                
		                             	<div class="project-info">
		                                   <a href="portfolioDetail.html"><h4 class="title-project text-cap">Wood Wall City</h4></a>
		                                    <a href="portfolioDetail.html" class="cateProject">Ecommercial</a>
		                              </div>
	                              </div>    
	                           
	                              <div class="element-item Ecommercial">
		                                <a class="img-contain-isotope" href="portfolioDetail.html">
		                                   <img src="images/Project/3.jpg" class="img-responsive" alt="Image">
		                                   </a>
		                                   <div class="project-info">
		                                   <a href="portfolioDetail.html"><h4 class="title-project text-cap">Bathroom furniture</h4></a>
		                                  <a href="portfolioDetail.html" class="cateProject">Residential</a>
		                              	</div>
	                        	  </div>
	                               
	                              <div class="element-item Ecommercial ">
		                                <a class="img-contain-isotope" href="portfolioDetail.html">
		                                  <img src="images/Project/4.jpg" class="img-responsive" alt="Image">
		                                  </a>
		                                  <div class="project-info">
		                                  <a href="portfolioDetail.html"><h4 class="title-project text-cap">Living room decor</h4></a>
		                                      <a href="portfolioDetail.html" class="cateProject">Residential</a>
		                                </div>
	                              </div>
	                           
	                              <div class="element-item Office">
		                                <a class="img-contain-isotope" href="portfolioDetail.html">
		                                 <img src="images/Project/5.jpg" class="img-responsive" alt="Image">
		                                 </a>
		                                 <div class="project-info">
		                                 <a href="portfolioDetail.html"><h4 class="title-project text-cap">open Space House</h4></a>
		                                      <a href="portfolioDetail.html" class="cateProject">Residential</a>
		                                </div>
	                              </div>
	                           
	                              <div class="element-item Office">
		                                <a class="img-contain-isotope" href="portfolioDetail.html">
		                                  <img src="images/Project/6.jpg" class="img-responsive" alt="Image">
		                                  </a>
		                                  <div class="project-info">
		                                  <a href="portfolioDetail.html"><h4 class="title-project text-cap">Sky Hotel</h4></a>
		                                      <a href="portfolioDetail.html" class="cateProject">Ecommercial</a>
		                                </div>
	                              </div>
	                           
	                              <div class="element-item Hospital ">
		                                <a class="img-contain-isotope" href="portfolioDetail.html">
		                                   <img src="images/Project/7.jpg" class="img-responsive" alt="Image">
		                                   </a>
		                                   <div class="project-info">
		                                   <a href="portfolioDetail.html"><h4 class="title-project text-cap">Ogrange Corporate</h4></a>
		                                      <a href="portfolioDetail.html" class="cateProject">Office</a>
		                                </div>
	                              </div>    
	                               
	                              <div class="element-item Hospital">
		                                
		                                  <img src="images/Project/8.jpg" class="img-responsive" alt="Image">
		                                <div class="project-info">
		                                 <a href="portfolioDetail.html"><h4 class="title-project text-cap">Ocean view Building</h4></a>
		                                      <a href="portfolioDetail.html" class="cateProject">Residential</a>
		                                </div>
	                              </div>
	                            </div>  <!-- End project Container -->
	                      </div> <!-- End  -->
	                    	<div class="overlay-arc">
	                    		<div class="layer-1">
	                    			<a href="portfolioGrid_1.html" class="ot-btn btn-dark-color text-cap">View all project</a>
	                    		</div>
	                    	</div>
				</section>
				<!-- End Section Isotop Lastest Project -->

				<section class="padding ">
					<div class="container">
					<div class="row">
						<div class="title-block">
							<h2 class="title text-cap">Lastest From News</h2>
							<div class="divider divider-1">
								<svg class="svg-triangle-icon-container">
								  <polygon class="svg-triangle-icon" points="6 11,12 0,0 0"></polygon>
								</svg>
							</div>
						</div>
						<!-- End Title -->
						<div class="lastest-blog-container">
							<div class="col-md-6">
								<article class="lastest-blog-item">
									<figure class="latest-blog-post-img effect-zoe">
										<a href="blogDetail.html">
											<img src="images/Blog/1.jpg" class="img-responsive" alt="Image">
										</a>
										<div class="latest-blog-post-date text-cap">
											<span class="day">21</span>
			                                <span class="month">May</span>
			                            </div>
			                        </figure>
			                        <div class="latest-blog-post-description">
			                            <a href="blogDetail.html"><h3>2016 Interior Design Trends</h3></a>
			                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
			                            
			                            <a href="blogDetail.html" class="ot-btn btn-main-color text-cap mgb0">
			                            	Continue Reading...
			                            </a>
			                        </div>
								</article>
							</div>
							<div class="col-md-6  ">
								<article class="lastest-blog-item">
									<figure class="latest-blog-post-img effect-zoe">
										<a href="blogDetail.html">
											<img src="images/Blog/2.jpg" class="img-responsive" alt="Image">
										</a>
										<div class="latest-blog-post-date text-cap">
											<span class="day">18</span>
			                                <span class="month">May</span>
			                            </div>
			                            
			                        </figure>
			                        <div class="latest-blog-post-description">
			                            <a href="blogDetail.html"><h3>15 Notable Products at ARC Interior Design Contest</h3></a>
			                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
			                            
			                            <a href="blogDetail.html" class="ot-btn btn-main-color text-cap mgb0">
			                            	Continue Reading...
			                            </a>
			                        </div>
								</article>
							</div>
						</div>
					</div>
					</div>
				</section>
				<!-- End Section Lastest Blog -->

				<section class="padding bg-grey">
					<div class="container">
					<div class="row">
						<div class="title-block">
							<h2 class="title text-cap">Our Partners</h2>
							<div class="divider divider-1">
								<svg class="svg-triangle-icon-container">
								  <polygon class="svg-triangle-icon" points="6 11,12 0,0 0"></polygon>
								</svg>
							</div>
						</div>
						<!-- End Title -->
						<div class="owl-partner-warp" >
	                    	<div class="customNavigation">
				                <a class="btn prev-partners"><i class="fa fa-angle-left"></i></a>
				                <a class="btn next-partners"><i class="fa fa-angle-right"></i></a>
	                    	</div><!-- End owl button -->

		                  	<div id="owl-partners" class="owl-carousel owl-theme owl-partners clearfix">
					                <div class="item">
					                    <a href="#">
					                      <img src="images/Partner/1.png" class="img-responsive" alt="Image">
					                    </a>
					                </div>
					                <div class="item">
					                    <a href="#">
					                      <img src="images/Partner/2.png" class="img-responsive" alt="Image">
					                    </a>
					                </div>
					                 <div class="item">
					                    <a href="#">
					                      <img src="images/Partner/3.png" class="img-responsive" alt="Image">
					                    </a>
					                </div>
					                 <div class="item">
					                    <a href="#">
					                      <img src="images/Partner/4.png" class="img-responsive" alt="Image">
					                    </a>
					                </div>
					                 <div class="item">
					                    <a href="#">
					                      <img src="images/Partner/5.png" class="img-responsive" alt="Image">
					                    </a>
					                </div>
					                <div class="item">
					                    <a href="#">
					                      <img src="images/Partner/1.png" class="img-responsive" alt="Image">
					                    </a>
					                </div>
					                <div class="item">
					                    <a href="#">
					                      <img src="images/Partner/2.png" class="img-responsive" alt="Image">
					                    </a>
					                </div>
					                 <div class="item">
					                    <a href="#">
					                      <img src="images/Partner/3.png" class="img-responsive" alt="Image">
					                    </a>
					                </div>
					                 <div class="item">
					                    <a href="#">
					                      <img src="images/Partner/4.png" class="img-responsive" alt="Image">
					                    </a>
					                </div>
					                 <div class="item">
					                    <a href="#">
					                      <img src="images/Partner/5.png" class="img-responsive" alt="Image">
					                    </a>
					                </div> 
		              	 	</div>
	  	              </div><!-- End row partners -->
					</div>
					</div>
				</section>
				<!-- End Section Owl Partners -->

				<section class="padding bg-parallax section-dark-testimonials">
					<div class="container">
					<div class="row">
						<div class="title-block">
							<h2 class="title text-cap">What Our Client Says</h2>
							<div class="divider divider-2">
								<svg class="svg-triangle-icon-container">
								  <polygon class="svg-triangle-icon" points="6 11,12 0,0 0"></polygon>
								</svg>
							</div>
						</div>
						<!-- End Title -->
						<div class="testimonial-warp testimonial-2-col">
				              <div class="customNavigation">
				                <a class="btn prev-testimonials-2-columns"><i class="fa fa-angle-left"></i></a>
				                <a class="btn next-testimonials-2-columns"><i class="fa fa-angle-right"></i></a>
				              </div>  
				              <div id="owl-testimonials-2-columns" class="owl-carousel owl-theme clearfix">
				              <div class="item item-testimonials text-left">
				                  <p class="quote-icon">“</p>
				                  <p><i>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</i></p>
				                  <div class="avatar-testimonials">
				                    <img src="images/Testimonials/1.jpg" class="img-responsive" alt="Image">
				                  </div>
				                  <h4 class="name-testimonials text-cap">Linda Campbell</h4>
				                  <span class="job-testimonials">CEO Finanace Theme Group</span>
				              </div><!-- end item -->
				              <div class="item item-testimonials text-left">
				                  <p class="quote-icon">“</p>
				                  <p><i>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</i></p>
				                  <div class="avatar-testimonials">
				                    <img src="images/Testimonials/2.jpg" class="img-responsive" alt="Image">
				                  </div>
				                  <h4 class="name-testimonials text-cap">John Walker</h4>
				                  <span class="job-testimonials">Photographer</span>
				              </div><!-- end item -->
				              <div class="item item-testimonials text-left">
				                  <p class="quote-icon">“</p>
				                  <p><i>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</i></p>
				                  <div class="avatar-testimonials">
				                    <img src="images/Testimonials/3.jpg" class="img-responsive" alt="Image">
				                  </div>
				                  <h4 class="name-testimonials text-cap">Cheryl Cruz</h4>
				                  <span class="job-testimonials">Marketing Manager</span>
				              </div><!-- end item -->
				              <div class="item item-testimonials text-left">
				                  <p class="quote-icon">“</p>
				                  <p><i>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</i></p>
				                  <div class="avatar-testimonials">
				                    <img src="images/Testimonials/4.jpg" class="img-responsive" alt="Image">
				                  </div>
				                  <h4 class="name-testimonials text-cap">James Smith</h4>
				                  <span class="job-testimonials">Senior Finance Manager</span>
				              </div><!-- end item -->
				              <div class="item item-testimonials text-left">
				                  <p class="quote-icon">“</p>
				                  <p><i>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</i></p>
				                  <div class="avatar-testimonials">
				                    <img src="images/Testimonials/5.jpg" class="img-responsive" alt="Image">
				                  </div>
				                  <h4 class="name-testimonials text-cap">Maria Garcia</h4>
				                  <span class="job-testimonials">Finance Director Theme Group</span>
				              </div><!-- end item -->
				              <div class="item item-testimonials text-left">
				                  <p class="quote-icon">“</p>
				                  <p><i>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</i></p>
				                  <div class="avatar-testimonials">
				                    <img src="images/Testimonials/6.jpg" class="img-responsive" alt="Image">
				                  </div>
				                  <h4 class="name-testimonials text-cap">Robert Johnson</h4>
				                  <span class="job-testimonials">Finance Assistant - PR Agency</span>
				              </div><!-- end item -->
				              </div>
			          	</div>
					</div>  
					</div>
				</section>
				<!-- End Section Owl Testimonials -->

				<section class="padding " style="padding: 9px 0 33px 0;">
					
				</section>
				<!-- End Section subcribe -->
<?php include('footer.php'); ?>